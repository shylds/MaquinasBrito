package br.com.maquinasbrito.model;

public class ToolModel {
    private int id;
    private String brand;
    private String model;
    private String typeOfTool;

    public ToolModel(){

    }

    public Integer getId(){
        return this.id;
    }

    public String getBrand(){
        return this.brand;
    }

    public String getModel(){
        return this.model;
    }

    public String getTypeOfTool(){
        return this.typeOfTool;
    }

    public void setId(int id){
        this.id = id;
    }

    public void setBrand(String brand){
        this.brand = brand;
    }

    public void setModel(String model){
        this.model = model;
    }

    public void setTypeOfTool(String typeOfTool){
        this.typeOfTool = typeOfTool;
    }
}
