package br.com.maquinasbrito.view;

import java.sql.SQLException;

import br.com.maquinasbrito.controller.ClientController;
import br.com.maquinasbrito.model.ClientModel;

public class SearcherClientTest {
    public static void main(String[] Args) throws SQLException{
        ClientController clientController = new ClientController();
        ClientModel clientModel = new ClientModel(5,"gracy", "Santos", "11949302531", "1112345678");

        ClientModel returnClient = clientController.searcherClientId(clientModel);
        
        //ClientModel returnClient = clientController.searcherClient(1);
        System.out.println(returnClient.getName());
        
    }
}
